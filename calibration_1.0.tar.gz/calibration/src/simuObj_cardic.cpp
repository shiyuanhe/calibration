#include "simuObj_cardic.hpp"


// voltage is stored in the first (and only column) of dataXReal;
//    It only has unique distict points, and has smaller size than the 
//    actual data set. 
// aux contains the auxillary information.
//      Its number of rows is of the same size as the actual data set. 
//      The first column is the time points.
//      The second column is where to find theta for this row. 
vec simuobj_cardic::yModel(const mat & theta, const mat & dataXReal, const mat & aux){
    int nSample = dataXReal.n_rows; // The actual sample size, larger than dataXReal.n_rows
    int pos; // where to get v and theta(v)
    vec result(nSample, fill::zeros); 
    mat A(4, 4, fill::zeros), exptA;
    double v, ot, istar;
    for(int i = 0; i < nSample; i++){
        v = dataXReal(i, 0);
        A = computeA( theta.row(i) );
        exptA = expmat(aux(i,0) * A);
        ot = exptA(1,3);
        istar = Gconst * ot * (v - Econst);
        result(i) = istar;
    }
    return result;
}

// https://math.stackexchange.com/questions/1291063/derivative-of-matrix-exponential-wrt-to-each-element-of-matrix
// Higham's "Complex Step Approximation"
mat simuobj_cardic::yModelPartial(const mat & theta, 
                                  const mat & dataXReal, 
                                  const mat & aux){
    int vSize = dataXReal.n_rows; // number of unique points for v
    mat result(vSize, 3);
    double v;
    
    rowvec tmpres(3);
    for(int i = 0; i < vSize; i++){
        v = dataXReal(i,0);
        tmpres(0) = computeADeriv(theta.row(i), aux(i,0), 0);
        tmpres(1) = computeADeriv(theta.row(i), aux(i,0), 1);
        tmpres(2) = computeADeriv(theta.row(i), aux(i,0), 2);
        result.row(i) = Gconst * tmpres * (v - Econst);
    }
    
    return result;
}

mat simuobj_cardic::computeA(const rowvec & theta){
    mat A(4,4,fill::zeros);
    A(0,0) = -theta(0)-theta(1);
    A(0,1) = theta(1);
    A(1,0) = theta(0);
    A(1,1) = -theta(1)-theta(2);
    A(2,0) = theta(1);
    A(0,2) = theta(0);
    A(2,2) = -theta(0)-theta(1);
    A(3,2)  = theta(1);
    A(2,3) = theta(0);
    A(3,3) = -theta(0);
    return A;
}

double simuobj_cardic::computeADeriv(const rowvec & theta_real, double t, int p){
    double h = 1e-8, deriv;
    rowvec theta_im(3, fill::zeros);
    theta_im(p) = h;
    
    cx_rowvec theta(theta_real, theta_im);
    
    cx_mat A(4,4,fill::zeros), exptA;
    
    A(0,0) = -theta(0)-theta(1);
    A(0,1) = theta(1);
    A(1,0) = theta(0);
    A(1,1) = -theta(1)-theta(2);
    A(2,0) = theta(1);
    A(0,2) = theta(0);
    A(2,2) = -theta(0)-theta(1);
    A(3,2) = theta(1);
    A(2,3) = theta(0);
    A(3,3) = -theta(0);
    exptA = expmat(t * A);
    deriv = imag(exptA(1,3)) / h;
    return deriv;
}

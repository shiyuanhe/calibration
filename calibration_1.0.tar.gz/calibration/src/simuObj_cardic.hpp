#ifndef SIMUOBJCARDIC_CLASS
#define SIMUOBJCARDIC_CLASS

#include "simuObj.hpp"


// The real data anallysis for the paper
// Matthew Plumlee, V. Roshan Joseph & Hui Yang
// Calibrating Functional Parameters in the Ion Channel Models of Cardiac Cells
class simuobj_cardic:
    public simuobj{
private:
    const double Gconst = 0.01; // muS/muC
    const double Econst = 20; // mV
public:
    
    // voltage is stored in the first (and only column) of dataXReal;
    // time is an auxilary variable and stored in aux.
    virtual vec yModel(const mat & theta, const mat & dataXReal, const mat & aux);
    
    // https://math.stackexchange.com/questions/1291063/derivative-of-matrix-exponential-wrt-to-each-element-of-matrix
    // Higham's "Complex Step Approximation"
    virtual mat yModelPartial(const mat & theta, const mat & dataXReal, const mat & aux);
    
     mat computeA(const rowvec & theta);
    
     double computeADeriv(const rowvec & theta_real, double t, int p);
    
    virtual mat yModelPartial2O(const mat & theta, const mat & dataXReal, const mat & aux){
        return arma::zeros(1,1);
    }
    
    virtual vec yModelPartial2OCross(const mat & theta, 
                             const mat & dataXReal, const mat & aux,
                             int i, int j){
        return arma::zeros<vec>(dataXReal.n_rows);
    }
    
};




#endif

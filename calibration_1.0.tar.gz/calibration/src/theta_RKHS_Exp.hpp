#ifndef THETAEXP_CLASS
#define THETAEXP_CLASS

#include "theta_RKHS.hpp"

class thetaRKSH_sqExp: public thetaRKSH{
public:
    thetaRKSH_sqExp(){
        set_dimNull(0);
    }
    
    
private:

    mat computeKernel(const mat & dataX1, const mat & dataX2){
        int ns1, ns2;
        ns1 = dataX1.n_rows;
        ns2 = dataX2.n_rows;
        
        mat kernelMat = mat(ns1, ns2, fill::zeros);
        rowvec  diff;
        double distIJ;
        for(int i = 0; i< ns1; i++)
            for(int  j = 0; j < ns2; j++){
                diff = dataX1.row(i) - dataX2.row(j);
                distIJ = sum(diff % diff);
                kernelMat(i,j) = exp(-5.0 * distIJ);
            }
            return kernelMat;
    }
    
    mat computeNull(const mat & dataX1){
        return mat(1,1);
    }
    
};

#endif
